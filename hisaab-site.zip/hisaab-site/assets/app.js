/* ---------- helpers ---------- */
const $ = (s, r=document) => r.querySelector(s);
const inr = n => "₹" + Math.round(n).toLocaleString("en-IN");
const short = n => { const a=Math.abs(n); if(a>=1e7) return "₹"+(n/1e7).toFixed(2)+" Cr"; if(a>=1e5) return "₹"+(n/1e5).toFixed(2)+" L"; return inr(n); };
const pct = n => (n*100).toFixed(1)+"%";

/* ---------- tax engine: FY 2026-27 (slabs unchanged by Budget 2026) ---------- */
const NEW_SLABS=[[400000,0],[800000,.05],[1200000,.10],[1600000,.15],[2000000,.20],[2400000,.25],[Infinity,.30]];
const oldSlabs = age => { const ex = age==="80"?500000:age==="60"?300000:250000;
  return [[ex,0],[Math.max(ex,500000),.05],[1000000,.20],[Infinity,.30]]; };
function slabTax(x, slabs){ let t=0,prev=0; for(const [lim,r] of slabs){ if(x>prev){ t+=(Math.min(x,lim)-prev)*r; } prev=lim; } return t; }
function baseTax(x, regime, age){
  if(x<=0) return 0;
  let t = slabTax(x, regime==="new"?NEW_SLABS:oldSlabs(age));
  if(regime==="new"){ if(x<=1200000) t=0; else t=Math.min(t, x-1200000); }   // rebate + marginal relief
  else if(x<=500000) t=Math.max(0,t-12500);
  return t;
}
function surchargeBands(regime){ return regime==="new" ? [[5e6,.10],[1e7,.15],[2e7,.25]] : [[5e6,.10],[1e7,.15],[2e7,.25],[5e7,.37]]; }
function taxBeforeCess(x, regime, age){
  const b = baseTax(x,regime,age); let T=0,r=0;
  for(const [th,rate] of surchargeBands(regime)) if(x>th){T=th;r=rate;}
  if(!r) return {base:b, sc:0};
  const atT = taxBeforeCess(T,regime,age); const capTotal = atT.base+atT.sc+(x-T);
  const sc = Math.max(0, Math.min(b*r, capTotal-b));
  return {base:b, sc};
}
function fullTax(x, regime, age="0"){
  const {base,sc}=taxBeforeCess(Math.max(0,x),regime,age); const cess=(base+sc)*.04;
  return {slab:slabTax(Math.max(0,x), regime==="new"?NEW_SLABS:oldSlabs(age)), base, sc, cess, total:base+sc+cess};
}

/* ---------- field builders ---------- */
function field(o){ // {id,label,min,max,step,value,pre,suf,hint}
  return `<div class="field"><div class="row"><label for="${o.id}">${o.label}</label>
  <div class="num">${o.pre?`<span>${o.pre}</span>`:""}<input id="${o.id}" inputmode="decimal" value="${o.value}" data-min="${o.min}" data-max="${o.max}">${o.suf?`<span>${o.suf}</span>`:""}</div></div>
  ${o.noslider?"":`<input type="range" id="${o.id}_r" aria-label="${o.label}" min="${o.min}" max="${o.max}" step="${o.step}" value="${o.value}">`}
  ${o.hint?`<div class="hint">${o.hint}</div>`:""}</div>`;
}
function seg(id,label,opts,val){ return `<div class="field"><div class="row"><label>${label}</label><div class="seg" id="${id}" data-val="${val}">${opts.map(([v,t])=>`<button type="button" data-v="${v}" aria-pressed="${v===val}">${t}</button>`).join("")}</div></div></div>`; }
const num = id => { const v=parseFloat(String($("#"+id).value).replace(/,/g,"")); return isNaN(v)?0:v; };
const segv = id => $("#"+id).dataset.val;
function wire(root, run){
  const fill = r => { const f=(r.value-r.min)/(r.max-r.min)*100; r.style.setProperty("--fill", Math.max(0,Math.min(100,f))+"%"); };
  root.querySelectorAll(".num input").forEach(inp=>{
    const r=$("#"+inp.id+"_r");
    if(r) fill(r);
    inp.addEventListener("input",()=>{ if(r){ r.value=num(inp.id); fill(r); } run(); });
    if(r) r.addEventListener("input",()=>{ inp.value=r.value; fill(r); run(); });
  });
  root.querySelectorAll(".seg").forEach(s=>s.addEventListener("click",e=>{
    const b=e.target.closest("button"); if(!b) return; s.dataset.val=b.dataset.v;
    s.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed", x===b)); run(); }));
  root.querySelectorAll("select").forEach(s=>s.addEventListener("change",run));
  run();
}
function ledger(rows){ return `<table class="ledger">${rows.map(([k,v,c=""])=>`<tr class="${c}"><td>${k}</td><td>${typeof v==="number"?inr(v):v}</td></tr>`).join("")}</table>`; }

/* growth chart: stacked invested + gains per year */
function growthChart(years, invested, value){
  const W=520,H=220,pl=56,pb=24,pt=10,pr=8, n=years.length, max=Math.max(...value,1);
  const mag=Math.pow(10,Math.floor(Math.log10(max))); const stepV=[1,2,2.5,5,10].map(m=>m*mag).find(s=>max/s<=5)||mag*10;
  const top=Math.ceil(max/stepV)*stepV, y=v=>pt+(H-pt-pb)*(1-v/top), bw=(W-pl-pr)/n;
  let g=""; for(let v=0;v<=top+1e-6;v+=stepV){ g+=`<line x1="${pl}" x2="${W-pr}" y1="${y(v)}" y2="${y(v)}" stroke="var(--rule)"/><text x="${pl-6}" y="${y(v)+4}" text-anchor="end" font-size="10" fill="var(--muted)" font-family="IBM Plex Mono">${short(v).replace("₹","")}</text>`; }
  let bars=""; const every=Math.ceil(n/10);
  years.forEach((yr,i)=>{ const x=pl+i*bw+bw*.15, w=bw*.7;
    bars+=`<rect x="${x}" y="${y(invested[i])}" width="${w}" height="${y(0)-y(invested[i])}" fill="var(--c2)" opacity=".55"/>`;
    bars+=`<rect x="${x}" y="${y(value[i])}" width="${w}" height="${Math.max(0,y(invested[i])-y(value[i]))}" fill="var(--accent)"/>`;
    if(i%every===0||i===n-1) bars+=`<text x="${x+w/2}" y="${H-8}" text-anchor="middle" font-size="10" fill="var(--muted)" font-family="IBM Plex Mono">${yr}</text>`; });
  return `<div class="chartbox"><div class="legend"><span><i style="background:var(--c2);opacity:.55"></i>Invested</span><span><i style="background:var(--accent)"></i>Returns</span></div>
  <svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Year by year growth">${g}${bars}</svg></div>`;
}

/* ---------- calculators ---------- */
const CALCS = [
/* ===== SALARY ===== */
{ id:"salary", group:"Salary & tax", name:"CTC to in-hand salary",
  title:"CTC to in-hand salary calculator",
  lede:"Enter your annual CTC to see your monthly take-home pay under both tax regimes for FY 2026-27, with PF, gratuity, professional tax and income tax broken out.",
  inputs:()=> field({id:"s_ctc",label:"Annual CTC",min:300000,max:10000000,step:50000,value:1200000,pre:"₹"})
   + field({id:"s_var",label:"Variable / bonus in CTC",min:0,max:2000000,step:10000,value:100000,pre:"₹",hint:"Paid once a year, so it is left out of the monthly figure."})
   + field({id:"s_basic",label:"Basic pay",min:30,max:60,step:1,value:40,suf:"% of CTC"})
   + seg("s_pf","Employer PF",[["cap","₹1,800/mo cap"],["full","12% of basic"]],"full")
   + seg("s_grat","Gratuity part of CTC",[["yes","Yes"],["no","No"]],"yes")
   + `<details class="more"><summary>Old regime deductions and other inputs</summary><div class="inner">`
   + seg("s_metro","Live in a metro?",[["yes","Yes"],["no","No"]],"no")
   + field({id:"s_rent",label:"Rent paid (annual)",min:0,max:1200000,step:6000,value:240000,pre:"₹"})
   + field({id:"s_80c",label:"Other 80C (ELSS, PPF, LIC)",min:0,max:150000,step:5000,value:50000,pre:"₹",hint:"Your own PF already counts toward the ₹1.5 lakh limit."})
   + field({id:"s_80d",label:"Health insurance (80D)",min:0,max:100000,step:1000,value:25000,pre:"₹"})
   + field({id:"s_nps",label:"Own NPS (80CCD 1B)",min:0,max:50000,step:5000,value:0,pre:"₹"})
   + field({id:"s_hl",label:"Home loan interest (self-occupied)",min:0,max:200000,step:5000,value:0,pre:"₹"})
   + field({id:"s_enps",label:"Employer NPS",min:0,max:14,step:1,value:0,suf:"% of basic",hint:"Deductible up to 14% of basic in the new regime and 10% in the old."})
   + field({id:"s_pt",label:"Professional tax (annual)",min:0,max:2500,step:100,value:2400,pre:"₹",noslider:true,hint:"₹2,400 in Karnataka. Varies by state; zero in some."})
   + `</div></details>`,
  run(){
    const ctc=num("s_ctc"), variable=Math.min(num("s_var"),ctc), basic=ctc*num("s_basic")/100;
    const epf = segv("s_pf")==="cap" ? Math.min(basic,180000)*.12 : basic*.12;
    const grat = segv("s_grat")==="yes" ? basic*.0481 : 0;
    const enpsPct=num("s_enps")/100, enps=basic*enpsPct;
    const gross = ctc-epf-grat-enps;
    const hra = basic*(segv("s_metro")==="yes"?.5:.4);
    const pt = num("s_pt");
    // new regime
    const newTaxable = Math.max(0, gross - 75000 + Math.max(0,enps-basic*.14));
    const tNew = fullTax(newTaxable,"new");
    // old regime
    const rent=num("s_rent");
    const hraEx = Math.max(0, Math.min(hra, rent-basic*.10, basic*(segv("s_metro")==="yes"?.5:.4)));
    const c80 = Math.min(150000, epf + num("s_80c"));
    const oldTaxable = Math.max(0, gross + Math.max(0,enps-basic*.10) - 50000 - pt - hraEx - c80 - num("s_80d") - Math.min(50000,num("s_nps")) - Math.min(200000,num("s_hl")));
    const tOld = fullTax(oldTaxable,"old");
    const best = tNew.total<=tOld.total ? "new":"old";
    const T = best==="new"?tNew:tOld, taxable = best==="new"?newTaxable:oldTaxable;
    const annualTake = gross - epf - pt - T.total;
    const monthly = (gross - variable - epf - pt - T.total)/12;
    return `<div class="hero-num"><div class="k">Monthly in-hand</div><div class="v">${inr(monthly)}</div>
      <div class="s">${best==="new"?"New":"Old"} regime is better for you · saves ${inr(Math.abs(tNew.total-tOld.total))} a year · plus ${inr(variable)} variable pay before tax</div></div>
      <div class="cmp"><div class="${best==="new"?"win":""}"><div class="k">Tax, new regime</div><div class="v">${inr(tNew.total)}</div></div>
      <div class="${best==="old"?"win":""}"><div class="k">Tax, old regime</div><div class="v">${inr(tOld.total)}</div></div></div>
      ${ledger([["Annual CTC",ctc,"total"],["Employer PF",epf,"minus"],["Gratuity",grat,"minus"],...(enps?[["Employer NPS",enps,"minus"]]:[]),
       ["Gross salary",gross,"total"],["  Basic",basic,"sub"],["  HRA",hra,"sub"],["  Variable / bonus",variable,"sub"],["  Special allowance",Math.max(0,gross-basic-hra-variable),"sub"],
       ["Employee PF",epf,"minus"],["Professional tax",pt,"minus"],[`Income tax (${best} regime, taxable ${short(taxable)})`,T.total,"minus"],
       ["Annual take-home",annualTake,"total"]])}
      <div class="adslot">Ad space · 336×280</div>`;
  },
},

/* ===== INCOME TAX ===== */
{ id:"tax", group:"Salary & tax", name:"Income tax",
  title:"Income tax calculator FY 2026-27",
  lede:"Compare tax under the new and old regimes for FY 2026-27 (Tax Year 2026-27). Includes the ₹12 lakh rebate, marginal relief, surcharge and 4% cess.",
  inputs:()=> field({id:"t_inc",label:"Gross annual income",min:0,max:20000000,step:25000,value:1500000,pre:"₹"})
   + seg("t_sal","Salaried or pensioner?",[["yes","Yes"],["no","No"]],"yes")
   + `<div class="field"><div class="row"><label for="t_age">Age</label><select id="t_age"><option value="0">Below 60</option><option value="60">60 to 79</option><option value="80">80 and above</option></select></div><div class="hint">Age changes the basic exemption only in the old regime.</div></div>`
   + field({id:"t_ded",label:"Old regime deductions",min:0,max:1000000,step:5000,value:200000,pre:"₹",hint:"80C, 80D, HRA exemption, home loan interest, NPS, all added up."}),
  run(){
    const inc=num("t_inc"), sal=segv("t_sal")==="yes", age=$("#t_age").value;
    const nT=Math.max(0,inc-(sal?75000:0)), oT=Math.max(0,inc-(sal?50000:0)-num("t_ded"));
    const n=fullTax(nT,"new"), o=fullTax(oT,"old",age), best=n.total<=o.total?"new":"old";
    const B=best==="new"?n:o;
    const col=(t,tax)=>ledger([["Taxable income",tax],["Tax on slabs",t.slab],["Rebate / marginal relief",t.slab-t.base,"minus"],["Surcharge",t.sc],["Health & education cess (4%)",t.cess],["Total tax",t.total,"total"]]);
    return `<div class="hero-num"><div class="k">Tax payable</div><div class="v">${inr(B.total)}</div>
      <div class="s"><span class="pill">${best} regime</span> saves ${inr(Math.abs(n.total-o.total))} · effective rate ${inc?pct(B.total/inc):"0%"} · monthly TDS about ${inr(B.total/12)}</div></div>
      <div class="cmp"><div class="${best==="new"?"win":""}"><div class="k">New regime</div><div class="v">${inr(n.total)}</div></div><div class="${best==="old"?"win":""}"><div class="k">Old regime</div><div class="v">${inr(o.total)}</div></div></div>
      <div><h3 style="margin:4px 0 0;font-size:14px">New regime working</h3>${col(n,nT)}</div>
      <div><h3 style="margin:4px 0 0;font-size:14px">Old regime working</h3>${col(o,oT)}</div>`;
  },
},

/* ===== SIP ===== */
{ id:"sip", group:"Investing", name:"SIP",
  title:"SIP calculator with annual step-up",
  lede:"See what a monthly SIP in a mutual fund could grow to. Add a yearly step-up to model increasing your SIP as your salary rises.",
  inputs:()=> field({id:"p_amt",label:"Monthly investment",min:500,max:200000,step:500,value:10000,pre:"₹"})
   + field({id:"p_rate",label:"Expected return",min:1,max:30,step:.5,value:12,suf:"% p.a."})
   + field({id:"p_yrs",label:"Time period",min:1,max:40,step:1,value:15,suf:"years"})
   + field({id:"p_step",label:"Annual step-up",min:0,max:25,step:1,value:0,suf:"%"})
   + field({id:"p_inf",label:"Inflation (for today's value)",min:0,max:10,step:.5,value:6,suf:"%"}),
  run(){
    const P=num("p_amt"), i=num("p_rate")/1200, Y=Math.round(num("p_yrs")), s=num("p_step")/100, inf=num("p_inf")/100;
    let bal=0, inv=0, amt=P; const yrs=[],I=[],V=[];
    for(let y=1;y<=Y;y++){ for(let m=0;m<12;m++){ bal=(bal+amt)*(1+i); inv+=amt; } yrs.push(y); I.push(inv); V.push(bal); amt*=1+s; }
    const real=bal/Math.pow(1+inf,Y);
    return `<div class="hero-num"><div class="k">Estimated value after ${Y} years</div><div class="v">${short(bal)}</div><div class="s">Worth about ${short(real)} in today's money at ${num("p_inf")}% inflation</div></div>
     ${ledger([["Total invested",inv],["Estimated returns",bal-inv],["Maturity value",bal,"total"]])}
     ${growthChart(yrs,I,V)}<div class="adslot">Ad space · 728×90</div>`;
  },
},

/* ===== LUMPSUM ===== */
{ id:"lumpsum", group:"Investing", name:"Lumpsum",
  title:"Lumpsum investment calculator",
  lede:"Work out what a one-time investment could grow to at a given annual return.",
  inputs:()=> field({id:"l_amt",label:"Investment",min:5000,max:10000000,step:5000,value:100000,pre:"₹"})
   + field({id:"l_rate",label:"Expected return",min:1,max:30,step:.5,value:12,suf:"% p.a."})
   + field({id:"l_yrs",label:"Time period",min:1,max:40,step:1,value:10,suf:"years"}),
  run(){ const P=num("l_amt"), r=num("l_rate")/100, Y=Math.round(num("l_yrs")); const yrs=[],I=[],V=[];
    for(let y=1;y<=Y;y++){yrs.push(y);I.push(P);V.push(P*Math.pow(1+r,y));} const fv=V[V.length-1]||P;
    return `<div class="hero-num"><div class="k">Value after ${Y} years</div><div class="v">${short(fv)}</div><div class="s">Your money multiplies ${(fv/P).toFixed(2)}×</div></div>
    ${ledger([["Invested",P],["Estimated returns",fv-P],["Total value",fv,"total"]])}${growthChart(yrs,I,V)}`; },
},

/* ===== SWP ===== */
{ id:"swp", group:"Investing", name:"SWP",
  title:"SWP calculator",
  lede:"Plan a systematic withdrawal from a mutual fund corpus and see how long it lasts.",
  inputs:()=> field({id:"w_corp",label:"Starting corpus",min:100000,max:50000000,step:100000,value:5000000,pre:"₹"})
   + field({id:"w_amt",label:"Monthly withdrawal",min:1000,max:500000,step:1000,value:40000,pre:"₹"})
   + field({id:"w_rate",label:"Expected return",min:1,max:20,step:.5,value:8,suf:"% p.a."})
   + field({id:"w_yrs",label:"Time period",min:1,max:40,step:1,value:20,suf:"years"}),
  run(){ let b=num("w_corp"); const W=num("w_amt"), i=num("w_rate")/1200, Y=Math.round(num("w_yrs")); let out=0, lastMonth=null;
    const yrs=[],I=[],V=[];
    for(let m=1;m<=Y*12;m++){ const w=Math.min(W,b); b-=w; out+=w; b*=1+i; if(b<=0&&lastMonth===null){lastMonth=m;b=0;} if(m%12===0){yrs.push(m/12);I.push(0);V.push(b);} }
    const status = lastMonth ? `<span class="pill" style="color:var(--warn)">Runs out in year ${Math.ceil(lastMonth/12)}</span>` : `<span class="pill">Lasts the full ${Y} years</span>`;
    return `<div class="hero-num"><div class="k">Balance after ${Y} years</div><div class="v">${short(b)}</div><div class="s">${status}</div></div>
    ${ledger([["Starting corpus",num("w_corp")],["Total withdrawn",out],["Final balance",b,"total"]])}${growthChart(yrs,I,V).replace("Invested","")}`; },
},

/* ===== GOAL ===== */
{ id:"goal", group:"Investing", name:"Goal planner",
  title:"Goal SIP planner",
  lede:"Know the cost of a goal in today's money? Find the monthly SIP you need, adjusted for inflation.",
  inputs:()=> field({id:"g_cost",label:"Goal cost today",min:50000,max:50000000,step:50000,value:2500000,pre:"₹"})
   + field({id:"g_yrs",label:"Years to goal",min:1,max:40,step:1,value:10,suf:"years"})
   + field({id:"g_inf",label:"Inflation",min:0,max:12,step:.5,value:6,suf:"%"})
   + field({id:"g_rate",label:"Expected return",min:1,max:20,step:.5,value:12,suf:"% p.a."}),
  run(){ const Y=num("g_yrs"), fvGoal=num("g_cost")*Math.pow(1+num("g_inf")/100,Y), i=num("g_rate")/1200, n=Y*12;
    const sip = fvGoal/(((Math.pow(1+i,n)-1)/i)*(1+i));
    return `<div class="hero-num"><div class="k">Monthly SIP needed</div><div class="v">${inr(sip)}</div><div class="s">For ${n} months</div></div>
    ${ledger([["Goal cost today",num("g_cost")],[`Goal cost in ${Y} years`,fvGoal],["You invest",sip*n],["Returns cover",fvGoal-sip*n,"total"]])}`; },
},

/* ===== EMI ===== */
{ id:"emi", group:"Loans & deposits", name:"Loan EMI",
  title:"Loan EMI calculator",
  lede:"Monthly EMI, total interest and a year-by-year repayment schedule for a home, car or personal loan.",
  inputs:()=> field({id:"e_amt",label:"Loan amount",min:50000,max:50000000,step:50000,value:3000000,pre:"₹"})
   + field({id:"e_rate",label:"Interest rate",min:5,max:24,step:.05,value:8.5,suf:"% p.a."})
   + field({id:"e_yrs",label:"Tenure",min:1,max:30,step:1,value:20,suf:"years"}),
  run(){ const P=num("e_amt"), i=num("e_rate")/1200, n=Math.round(num("e_yrs"))*12;
    const emi = i? P*i*Math.pow(1+i,n)/(Math.pow(1+i,n)-1) : P/n;
    let b=P, rows="", yi=0, yp=0;
    for(let m=1;m<=n;m++){ const int=b*i, pr=emi-int; b-=pr; yi+=int; yp+=pr;
      if(m%12===0){ rows+=`<tr><td>Year ${m/12}</td><td>${inr(yp)}</td><td>${inr(yi)}</td><td>${inr(Math.max(0,b))}</td></tr>`; yi=0; yp=0; } }
    return `<div class="hero-num"><div class="k">Monthly EMI</div><div class="v">${inr(emi)}</div><div class="s">Interest is ${pct((emi*n-P)/(emi*n))} of everything you repay</div></div>
     ${ledger([["Principal",P],["Total interest",emi*n-P],["Total payment",emi*n,"total"]])}
     <details class="more"><summary>Year-by-year schedule</summary><div class="tablewrap" style="margin-top:10px"><table class="amort"><tr><th>Year</th><th>Principal</th><th>Interest</th><th>Balance</th></tr>${rows}</table></div></details>`; },
},

/* ===== FD ===== */
{ id:"fd", group:"Loans & deposits", name:"Fixed deposit",
  title:"FD calculator",
  lede:"Maturity value of a bank fixed deposit with quarterly compounding, and the TDS your bank may deduct.",
  inputs:()=> field({id:"f_amt",label:"Deposit",min:5000,max:10000000,step:5000,value:500000,pre:"₹"})
   + field({id:"f_rate",label:"Interest rate",min:3,max:10,step:.05,value:7,suf:"% p.a.",hint:"Check your bank's current card rate."})
   + field({id:"f_yrs",label:"Tenure",min:1,max:10,step:1,value:5,suf:"years"}),
  run(){ const P=num("f_amt"), r=num("f_rate")/100, Y=num("f_yrs"); const M=P*Math.pow(1+r/4,4*Y), annualInt=(M-P)/Y;
    return `<div class="hero-num"><div class="k">Maturity value</div><div class="v">${inr(M)}</div><div class="s">Effective annual yield ${pct(Math.pow(1+r/4,4)-1)}</div></div>
     ${ledger([["Deposit",P],["Interest earned",M-P],["Maturity value",M,"total"]])}
     <p class="note">Average interest of about ${inr(annualInt)} a year. Interest is added to your income and taxed at your slab rate.</p>`; },
},

/* ===== PPF ===== */
{ id:"ppf", group:"Loans & deposits", name:"PPF",
  title:"PPF calculator",
  lede:"Public Provident Fund maturity over 15 years, with yearly deposits up to ₹1.5 lakh.",
  inputs:()=> field({id:"pp_amt",label:"Yearly deposit",min:500,max:150000,step:500,value:150000,pre:"₹"})
   + field({id:"pp_rate",label:"Interest rate",min:5,max:10,step:.1,value:7.1,suf:"% p.a.",hint:"Set by the government each quarter. Check the current rate."})
   + field({id:"pp_yrs",label:"Years",min:15,max:50,step:5,value:15,suf:"years",hint:"15-year lock-in, then extendable in 5-year blocks."}),
  run(){ const D=num("pp_amt"), r=num("pp_rate")/100, Y=Math.round(num("pp_yrs")); let b=0; const yrs=[],I=[],V=[];
    for(let y=1;y<=Y;y++){ b=(b+D)*(1+r); yrs.push(y); I.push(D*y); V.push(b); }
    return `<div class="hero-num"><div class="k">Maturity value</div><div class="v">${short(b)}</div><div class="s">Fully tax-free (EEE) under the old regime</div></div>
    ${ledger([["Total deposited",D*Y],["Interest earned",b-D*Y],["Maturity value",b,"total"]])}${growthChart(yrs,I,V)}`; },
},
];
const COMBOS={
  salary:["#0891b2","#4f46e5","#22d3ee","#818cf8"],
  tax:["#e11d48","#f59e0b","#fb7185","#fbbf24"],
  sip:["#2563eb","#06b6d4","#60a5fa","#22d3ee"],
  lumpsum:["#7c3aed","#db2777","#a78bfa","#f472b6"],
  swp:["#0d9488","#65a30d","#2dd4bf","#a3e635"],
  goal:["#ea580c","#ca8a04","#fb923c","#facc15"],
  emi:["#1e40af","#0ea5e9","#93c5fd","#38bdf8"],
  fd:["#16a34a","#0891b2","#4ade80","#22d3ee"],
  ppf:["#c026d3","#6d28d9","#e879f9","#a78bfa"]};
const hueVars = id => { const k=COMBOS[id]; return k?`--lc:${k[0]};--lc2:${k[1]};--dc:${k[2]};--dc2:${k[3]}`:""; };

/* ---------- page boot ---------- */
(function(){
  const id=document.body.dataset.calc, c=CALCS.find(x=>x.id===id);
  if(!c) return;
  $("#inputs").innerHTML=c.inputs();
  wire($("#calc-root"), ()=>{ $("#out").innerHTML=c.run(); });
})();
/* ---------- light / dark toggle ---------- */
const MOON='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
const SUN='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
const tbtn=$("#themebtn"), root=document.documentElement;
const isDark=()=> root.dataset.theme ? root.dataset.theme==="dark" : matchMedia("(prefers-color-scheme: dark)").matches;
function paintBtn(){ tbtn.innerHTML = isDark() ? SUN+"Light mode" : MOON+"Dark mode"; }
try{ const t=localStorage.getItem("hisaab_theme"); if(t) root.dataset.theme=t; }catch(e){}
paintBtn();
tbtn.addEventListener("click",()=>{ const t=isDark()?"light":"dark"; root.dataset.theme=t; try{localStorage.setItem("hisaab_theme",t);}catch(e){} paintBtn(); });
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change",paintBtn);
